@echo off
setlocal
cd /d %~dp0
title Animica CPU Miner
set CONFIG=animica-miner.config.json
set MINER_EXE=animica-miner.exe
echo Connecting to stratum+tcp://pool.animica.org:3333
if exist %MINER_EXE% (
  %MINER_EXE% --config %CONFIG%
) else (
  set PYTHON_CMD=
  where py >nul 2>nul
  if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
  if not defined PYTHON_CMD (
    where python >nul 2>nul
    if %ERRORLEVEL%==0 set PYTHON_CMD=python
  )
  if not defined PYTHON_CMD (
    echo Neither animica-miner.exe nor Python 3.10+ was found.
    echo Re-download the latest miner bundle or install Python and retry.
    pause
    exit /b 1
  )
  %PYTHON_CMD% animica_cpu_miner.py --config %CONFIG%
)
set EXIT_CODE=%ERRORLEVEL%
echo.
if not %EXIT_CODE%==0 echo Miner exited with status %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
