#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
echo "Connecting to stratum+tcp://pool.animica.org:3333"
if [ -x "./animica-miner" ]; then
  ./animica-miner --config "animica-miner.config.json"
elif command -v python3 >/dev/null 2>&1; then
  python3 animica_cpu_miner.py --config "animica-miner.config.json"
elif command -v python >/dev/null 2>&1; then
  python animica_cpu_miner.py --config "animica-miner.config.json"
else
  echo "Neither ./animica-miner nor Python 3.10+ was found."
  read -r -p "Press Return to close this window."
  exit 1
fi
status=$?
echo ""
if [ "$status" -ne 0 ]; then echo "Miner exited with status $status."; fi
read -r -p "Press Return to close this window."
exit $status
