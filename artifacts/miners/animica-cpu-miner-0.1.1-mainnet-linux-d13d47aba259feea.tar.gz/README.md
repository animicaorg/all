# Animica CPU Miner Starter Bundle

Version: 0.1.1
Network: mainnet
Pool profile: hashshare
Pool mode: PPS
Algorithm: Animica HashShare
Recommended device: CPU miner
Detected endpoint: stratum+tcp://pool.animica.org:3333
Configured worker: animica-cpu

## Quick start

1. Put your Animica payout address into `animica-miner.config.json`.
2. Keep the detected pool host and port as-is unless your operator told you otherwise.
3. Run the included launcher for your platform:
   - Windows: `start_mining.bat`
   - macOS: `start_mining.command`
   - Ubuntu/Linux: `start_mining.sh`
4. The launcher opens a terminal, prints the target pool, and starts `animica-miner`.

## Manual command

Windows:
`animica-miner.exe --pool-url stratum+tcp://pool.animica.org:3333 --address YOUR_ANIMICA_ADDRESS --worker animica-cpu --pool-mode pps`

macOS:
`./animica-miner --pool-url stratum+tcp://pool.animica.org:3333 --address YOUR_ANIMICA_ADDRESS --worker animica-cpu --pool-mode pps`

Linux:
`./animica-miner --pool-url stratum+tcp://pool.animica.org:3333 --address YOUR_ANIMICA_ADDRESS --worker animica-cpu --pool-mode pps`

## Payout address

Use an address that matches the active network. The starter config ships with `YOUR_ANIMICA_ADDRESS`.

## Worker naming

Worker names are informational. This bundle uses `animica-cpu` by default. Good patterns:
- `office-cpu`
- `mac-mini-01`
- `ubuntu-rig-a`

## Pool notes

- Mode: PPS (accepted shares earn deterministic per-share credit)
- Fee: not published%
- Payout minimum: not published
- Payout cadence: every 600 seconds
- Host source: request_host

## Warnings

- None

## Troubleshooting

- Bundles prefer `animica-miner` executable. If it is missing, the launcher falls back to `animica_cpu_miner.py` + Python 3.10+.
- If the miner cannot connect, confirm that `pool.animica.org:3333` is reachable from this machine.
- If you are mining from another computer and the host resolves to `localhost` or `127.0.0.1`, ask the operator to set `ANIMICA_PUBLIC_STRATUM_HOST`.
- Personalized bundles can be re-generated from the mining portal with your payout address prefilled.
