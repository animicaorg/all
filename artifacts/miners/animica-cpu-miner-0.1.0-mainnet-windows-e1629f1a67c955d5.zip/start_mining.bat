@echo off
setlocal
cd /d %~dp0
title Animica CPU Miner
set CONFIG=animica-miner.config.json
set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 set PYTHON_CMD=py -3
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 set PYTHON_CMD=python
)
if not defined PYTHON_CMD (
  echo Python 3.10+ was not found on PATH.
  echo Install Python and run this launcher again.
  pause
  exit /b 1
)
echo Connecting to stratum+tcp://127.0.0.1:3333
%PYTHON_CMD% animica_cpu_miner.py --config %CONFIG%
set EXIT_CODE=%ERRORLEVEL%
echo.
if not %EXIT_CODE%==0 echo Miner exited with status %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
