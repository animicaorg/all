# Animica CPU Miner Starter Bundle

Version: 0.1.0
Network: mainnet
Pool profile: hashshare
Algorithm: Animica HashShare
Recommended device: CPU miner
Detected endpoint: stratum+tcp://127.0.0.1:3333
Configured worker: animica-cpu

## Quick start

1. Put your Animica payout address into `animica-miner.config.json`.
2. Keep the detected pool host and port as-is unless your operator told you otherwise.
3. Run the included launcher for your platform:
   - Windows: `start_mining.bat`
   - macOS: `start_mining.command`
   - Ubuntu/Linux: `start_mining.sh`
4. The launcher opens a terminal, prints the target pool, and starts the miner.

## Manual command

Windows:
`py -3 animica_cpu_miner.py --host 127.0.0.1 --port 3333 --address YOUR_ANIMICA_ADDRESS --worker animica-cpu --threads 4`

macOS:
`python3 animica_cpu_miner.py --host 127.0.0.1 --port 3333 --address YOUR_ANIMICA_ADDRESS --worker animica-cpu --threads 4`

Linux:
`python3 animica_cpu_miner.py --host 127.0.0.1 --port 3333 --address YOUR_ANIMICA_ADDRESS --worker animica-cpu --threads 4`

## Payout address

Use an address that matches the active network. The starter config ships with `YOUR_ANIMICA_ADDRESS`.

## Worker naming

Worker names are informational. This bundle uses `animica-cpu` by default. Good patterns:
- `office-cpu`
- `mac-mini-01`
- `ubuntu-rig-a`

## Pool notes

- Fee: not published%
- Payout minimum: not published
- Host source: request_host

## Warnings

- The resolved stratum host is local-only. Miners on other machines will need a public host override.

## Troubleshooting

- If Python is missing, install Python 3.10 or newer and re-run the launcher.
- If the miner cannot connect, confirm that `127.0.0.1:3333` is reachable from this machine.
- If you are mining from another computer and the host resolves to `localhost` or `127.0.0.1`, ask the operator to set `ANIMICA_PUBLIC_STRATUM_HOST`.
- Personalized bundles can be re-generated from the mining portal with your payout address prefilled.
