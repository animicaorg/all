#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
PYTHON_BIN=""
if command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="python3"
elif command -v python >/dev/null 2>&1; then
  PYTHON_BIN="python"
else
  echo "Python 3.10+ was not found on PATH."
  read -r -p "Press Return to close this window."
  exit 1
fi
echo "Connecting to stratum+tcp://127.0.0.1:3333"
"$PYTHON_BIN" animica_cpu_miner.py --config "animica-miner.config.json"
status=$?
echo ""
if [ "$status" -ne 0 ]; then echo "Miner exited with status $status."; fi
read -r -p "Press Return to close this window."
exit $status
